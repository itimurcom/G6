<?php
namespace App\Controllers;

use App\core\Controller;
use App\core\Request;

class CalendarController extends Controller
{
    public function index(Request $request): string {
        return $this->render('pages/calendar', [
            'title' => 'Календар',
            'extra_css' => [
                '/assets/css/calendar.css',
                '/assets/css/icons.css',
                ],
            'extra_js' => [
                '/assets/js/calendar/calendar.events.js',
                '/assets/js/calendar/calendar.data.js',
                '/assets/js/calendar/calendar.ui.js',
                ],
            'modules_js'   => [
                // '/assets/js/calendar/main.js',
            ]   ,
            ]);
    }
}
