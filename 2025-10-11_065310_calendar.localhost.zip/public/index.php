<?php
            
// === ROLE REGISTRATION LOGIC (sanitizer for /register) ===
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $path = strtok($_SERVER['REQUEST_URI'] ?? '/', '?') ?: '/';
    if ($path === '/register') {
        $cfg = @include dirname(__DIR__) . '/config/auth.php';
        $mode = $cfg['registration']['mode'] ?? 'invite';
        $allow = $cfg['registration']['allow_roles'] ?? ['user'];
        $code  = $cfg['registration']['admin_invite_code'] ?? 'CHANGE_ME_ADMIN_CODE';

        $requested = isset($_POST['role']) ? (string)$_POST['role'] : 'user';
        $adminCode = isset($_POST['admin_code']) ? (string)$_POST['admin_code'] : '';

        $final = 'user';
        if ($mode === 'dev') {
            if (in_array($requested, $allow, true)) $final = $requested;
        } elseif ($mode === 'invite') {
            if ($requested === 'admin' && is_string($adminCode) && $adminCode !== '' && hash_equals($code, $adminCode)) {
                $final = 'admin';
            }
        } elseif ($mode === 'bootstrap') {
            if ($requested === 'admin' && !\App\Core\Auth::adminsExist()) {
                $final = 'admin';
            }
        }
        $_POST['role'] = $final;
        // Back-compat flag
        $_POST['is_admin'] = ($final === 'admin') ? '1' : '0';
    }
}
// === /ROLE REGISTRATION LOGIC ===


require_once __DIR__ . '/../vendor/autoload.php';

use App\Core\Request;
use App\Core\Router;
use App\Core\EventsController;
use App\Controllers\AuthController;
use App\Core\Auth;

$request = new Request();
$router  = new Router($request);

// favicon без 404
$router->get('/favicon.ico', function(){
    header('Content-Type: image/x-icon');
    http_response_code(204);
});


$router->get('/',                           [\App\Controllers\HomeController::class,            'planning']);
$router->get('/calendar',                   [\App\Controllers\CalendarController::class,        'index']);
$router->get('/cabinet',                    [\App\Controllers\CabinetController::class,         'cabinet']);



// ---- API V2 (table-like) ----
$router->get('/api/events/by-date',         [\App\Controllers\ApiEventsController::class,       'byDate']);
$router->get('/api/events/by-range',        [\App\Controllers\ApiEventsController::class,       'byRange']);
$router->get('/api/events/get',             [\App\Controllers\ApiEventsController::class,       'get']);
$router->get('/api/events/search',          [\App\Controllers\ApiEventsController::class,       'search']);

$router->post('/api/events/create',         [\App\Controllers\ApiEventsController::class,       'create']);
$router->post('/api/events/update',         [\App\Controllers\ApiEventsController::class,       'update']);
$router->post('/api/events/delete',         [\App\Controllers\ApiEventsController::class,       'delete']);
$router->post('/api/events/done',           [\App\Controllers\ApiEventsController::class,       'done']);
$router->post('/api/events/urgent',         [\App\Controllers\ApiEventsController::class,       'urgent']);
// ---- Users API ----
$router->get('/api/users/get'
,          [\App\Controllers\ApiUsersController::class, 'get']);
$router->get('/api/users/name',         [\App\Controllers\ApiUserNameController::class, 'name']);



// ---- Backup API (export/import) ----
$router->get('/api/backup/export',          [\App\Controllers\ApiBackupController::class,       'export']);
$router->get('/api/backup/diag',            [\App\Controllers\ApiBackupController::class,       'diag']);
$router->post('/api/backup/import',         [\App\Controllers\ApiBackupController::class,       'import']);

// Legacy aliases (kept for compatibility)
// $router->get('/api/events', [\App\Controllers\ApiBackupController::class, 'export']);
$router->get('/api/events',                 [\App\Controllers\ApiBackupController::class,       'events']);
$router->get('/api/events/diag',            [\App\Controllers\ApiBackupController::class,       'diag']);
$router->get('/api/repair',                 [\App\Controllers\ApiBackupController::class,       'repair']);        // плоский
$router->get('/api/backup/repair-dups',     [\App\Controllers\ApiBackupController::class,       'repair']);

$router->post('/api/events/store',          [\App\Controllers\ApiBackupController::class,       'import']);

$router->post('/cabinet/profile/update',    [\App\Controllers\CabinetController::class, 'updateProfile']);
$router->post('/cabinet/password/change',   [\App\Controllers\CabinetController::class, 'changePassword']);

$router->get('/logout',                    [\App\Controllers\AuthController::class, 'logout']);


// MySQL conrollers
// $router->get('/api/mysql/diag',             [\App\Controllers\ApiMysqlEventsController::class,  'diag']);
// $router->get('/api/mysql/events/by-date',   [\App\Controllers\ApiMysqlEventsController::class,  'listByDate']);
// $router->get('/api/mysql/events/by-range',  [\App\Controllers\ApiMysqlEventsController::class,  'listByRange']);
// $router->get('/api/mysql/events/get',       [\App\Controllers\ApiMysqlEventsController::class,  'getById']);

// $router->post('/api/mysql/events/create',   [\App\Controllers\ApiMysqlEventsController::class,  'create']);
// $router->post('/api/mysql/events/update',   [\App\Controllers\ApiMysqlEventsController::class,  'update']);
// $router->post('/api/mysql/events/delete',   [\App\Controllers\ApiMysqlEventsController::class,  'delete']);
// $router->post('/api/mysql/events/done',     [\App\Controllers\ApiMysqlEventsController::class,  'setDone']);
// $router->post('/api/mysql/events/urgent',   [\App\Controllers\ApiMysqlEventsController::class,  'setUrgent']);


// === Users/Auth (MVP) ===
$router->get('/login',    [\App\Controllers\AuthController::class, 'loginForm']);
$router->post('/login',   [\App\Controllers\AuthController::class, 'login']);
$router->get('/register', [\App\Controllers\AuthController::class, 'registerForm']);
$router->post('/register',[\App\Controllers\AuthController::class, 'register']);
$router->post('/logout',  [\App\Controllers\AuthController::class, 'logout']);

// // Secure /cabinet behind auth
// $router->get('/cabinet', function($req){
//     if (!\App\Core\Auth::check()) { header('Location: /login', true, 302); return ''; }
//     return (new \App\Controllers\CabinetController())->cabinet($req);
// });

$router->get('/password/setup', [\App\Controllers\AuthController::class, 'passwordSetupForm']);
$router->post('/password/setup', [\App\Controllers\AuthController::class, 'passwordSetupSave']);

// Exact paths that require auth (no subpaths)
$_PROTECTED = ['/', '/calendar', '/calendar/', '/cabinet', '/cabinet/'];

$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?? '/';
if (!\App\Core\Auth::check() && in_array($path, $_PROTECTED, true)) {
    header('Location: /login', true, 302);
    exit;
}
$router->resolve();



function console_log($value, $label = 'PHP') {
    $js = json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    echo "<script>console.log('[{$label}]', {$js});</script>";
}
